---
name: archimate-plantuml-rules
description: Правила записи моделей ArchiMate в PlantUML для проектов RetailPro на этапе 3 и при проверке на этапе 4. Структура .puml-файла, полный список макросов и префиксов идентификаторов, макросы отношений и направлений, ограничения линтера archimate_check, порядок исправления ошибок, формат model/03_PlantUML.md. Загружай перед созданием, исправлением или проверкой любого .puml-файла.
compatibility: opencode
---

# Запись ArchiMate в PlantUML

Навык используется:
- `ea-modeler` - строит и исправляет `diagrams/*.puml` (этап 3);
- `ea-reviewer` - проверяет модель и сверяет макросы и префиксы
  (этап 4);
- `ea-analyst` - если в отчетах этапов 5-6 приводятся фрагменты
  PlantUML.

Какие элементы и отношения извлекать из текста, описано в навыке
`archimate-extraction-rules`. Элементы слоя Implementation и их
отношения - в навыке `archimate-implementation-rules`. Здесь описано
только **как записать готовые элементы и отношения в PlantUML** так,
чтобы файл компилировался и проходил инструмент `archimate_check`.

## 1. Главные принципы

1. **Модель = `01_Elements.md` + `02_Relationships.md`.** Все id,
   названия и типы берутся оттуда без изменений. Новых элементов
   и отношений не добавляй; нужен новый элемент - сообщи об этом в
   отчете.
2. **Объявляй до использования.** Если id встретился в отношении, но
   не был объявлен, PlantUML молча создаст пустую сущность без
   ошибки. Это самая коварная ошибка (код возврата 0).
3. **Успешная компиляция не доказывает корректность.** Тип элемента
   и направление отношения PlantUML не проверяет. Фразу "модель
   корректна" можно писать только после результата `PASS` от
   `archimate_check` и только вместе с оговоркой, что смысловая
   проверка остается за ревьюером и человеком.
4. **Одна диаграмма - одно представление** (раздел 5).

## 2. Структура файла

```
@startuml
!include <archimate/Archimate>
title <краткое название представления>

' --- Motivation ---
...объявления элементов слоя...
' --- Business ---
...
' --- Application ---
...
' --- Relationships ---
...все отношения...
@enduml
```

Правила:
1. Первая строка `@startuml`, вторая `!include <archimate/Archimate>`,
   последняя `@enduml`. Без `@enduml` PlantUML отвечает "No diagram
   found".
2. Кодировка UTF-8. Имя файла: латиница, snake_case, расширение
   `.puml`, с указанием представления и состояния:
   `retailpro_application_tobe.puml`.
3. Сначала **все** элементы по слоям (порядок: Motivation, Strategy,
   Business, Application, Technology, Implementation), затем **все**
   отношения. Комментарии - строки, начинающиеся с `'`.
4. Каждое объявление и каждое отношение записывается **одной
   строкой** без переносов внутри скобок.
5. Не используй `Grouping`, вложенные блоки `{ ... }`, цвета и
   дополнительные аргументы макросов: линтер `archimate_check` их не
   распознает и сообщит о "необъявленных" id.

## 3. Макросы элементов и префиксы идентификаторов

Синтаксис: `Слой_Тип(id, "Название")`. Перенос строки в названии
записывается как `\n`. Внутри названия не используй двойные кавычки
(вместо них - «ёлочки»).

Все префиксы проверяются инструментом `archimate_check`:
несоответствие префикса и макроса дает `ERROR`.

| Слой | Элемент | Макрос | Префикс |
|---|---|---|---|
| Motivation | Stakeholder | `Motivation_Stakeholder` | `st_` |
| Motivation | Driver | `Motivation_Driver` | `drv_` |
| Motivation | Assessment | `Motivation_Assessment` | `ass_` |
| Motivation | Goal | `Motivation_Goal` | `goal_` |
| Motivation | Outcome | `Motivation_Outcome` | `out_` |
| Motivation | Principle | `Motivation_Principle` | `pr_` |
| Motivation | Requirement | `Motivation_Requirement` | `req_` |
| Motivation | Constraint | `Motivation_Constraint` | `con_` |
| Strategy | Capability | `Strategy_Capability` | `cap_` |
| Strategy | Resource | `Strategy_Resource` | `res_` |
| Strategy | Value Stream | `Strategy_ValueStream` | `vs_` |
| Strategy | Course of Action | `Strategy_CourseOfAction` | `coa_` |
| Business | Actor | `Business_Actor` | `ba_` |
| Business | Role | `Business_Role` | `br_` |
| Business | Process | `Business_Process` | `bp_` |
| Business | Function | `Business_Function` | `fn_` |
| Business | Event | `Business_Event` | `be_` |
| Business | Service | `Business_Service` | `bs_` |
| Business | Object | `Business_Object` | `bo_` |
| Application | Component | `Application_Component` | `app_` |
| Application | Service | `Application_Service` | `as_` |
| Application | Interface | `Application_Interface` | `ai_` |
| Application | Data Object | `Application_DataObject` | `data_` |
| Application | Function | `Application_Function` | `af_` |
| Technology | Node | `Technology_Node` | `node_` |
| Technology | Device | `Technology_Device` | `dev_` |
| Technology | System Software | `Technology_SystemSoftware` | `sw_` |
| Technology | Service | `Technology_Service` | `ts_` |
| Technology | Artifact | `Technology_Artifact` | `art_` |
| Technology | Communication Network | `Technology_CommunicationNetwork` | `net_` |
| Implementation | Work Package | `Implementation_WorkPackage` | `wp_` |
| Implementation | Deliverable | `Implementation_Deliverable` | `del_` |
| Implementation | Plateau | `Implementation_Plateau` | `pl_` |
| Implementation | Gap | `Implementation_Gap` | `gap_` |
| Implementation | Event | `Implementation_Event` | `ie_` |

Правила идентификаторов:
- формат `префикс_snake_case`: латиница, строчные буквы, цифры и
  подчеркивания, без пробелов и дефисов, не начинается с цифры, до
  30 символов;
- префикс определяется типом элемента и **обязан соответствовать
  макросу**;
- id уникален в пределах файла и совпадает с id в `01_Elements.md`;
- для элементов Implementation читаемый идентификатор `WP-03`
  превращается в `wp_03_cdp` и выносится в начало названия:
  "WP-03 Внедрить CDP".

## 4. Макросы отношений

Синтаксис: `Rel_Тип(источник, цель)` или
`Rel_Тип(источник, цель, "подпись")`. Порядок аргументов задает
направление. Какие пары элементов допустимы - см. таблицы
отношений в навыках `archimate-extraction-rules` (раздел 3) и
`archimate-implementation-rules` (раздел 3).

| Отношение | Макрос | Подпись |
|---|---|---|
| Association | `Rel_Association` | по желанию |
| Influence | `Rel_Influence` | по желанию |
| Realization | `Rel_Realization` | не нужна |
| Serving | `Rel_Serving` | по желанию |
| Assignment | `Rel_Assignment` | не нужна |
| Access | `Rel_Access`; варианты `Rel_Access_r`, `Rel_Access_w`, `Rel_Access_rw` | не нужна |
| Flow | `Rel_Flow` | **обязательна**: что передается |
| Triggering | `Rel_Triggering` | не нужна |
| Composition | `Rel_Composition` | не нужна |
| Aggregation | `Rel_Aggregation` | не нужна |
| Specialization | `Rel_Specialization` | не нужна |

Варианты с направлением раскладки диаграммы: к имени макроса
добавляется `_Up`, `_Down`, `_Left` или `_Right`, например
`Rel_Flow_Down(app_crm, app_cdp, "данные клиента")`. Направление
влияет только на расположение, но не на смысл отношения.

Доступ: `Rel_Access_r` - только чтение, `Rel_Access_w` - только
запись, `Rel_Access_rw` - чтение и запись; если в
`02_Relationships.md` вид доступа не указан, используй `Rel_Access`.

Макросы `Lay_Up`, `Lay_Down`, `Lay_Left`, `Lay_Right` в библиотеке
ArchiMate **отсутствуют** (они относятся к другим библиотекам, и
компиляция с ними завершается ошибкой). Для управления раскладкой
используй суффиксы направления у `Rel_...`.

## 5. Размер и состав диаграммы

1. Одна диаграмма - одно представление, не более 3 слоев и не более
   25 элементов. Если элементов больше, раздели модель на
   диаграммы: мотивационная, бизнес-процессы, прикладная,
   технологическая, дорожная карта.
2. Элементы, общие для нескольких диаграмм, повторяются с теми же
   id и названиями.
3. Состояние **As-is** и **To-be** показывай отдельными файлами
   (`..._asis.puml`, `..._tobe.puml`). Элемент с состоянием "Оба"
   попадает в оба файла. В id состояние не кодируется.
4. Названия не должны быть длиннее ~35 символов в строке; длинные
   названия разбивай через `\n`.
5. Не создавай элементы только ради красоты схемы: каждый элемент
   должен быть в `01_Elements.md`.

## 6. Проверка и исправление ошибок

После записи файла вызови инструмент `archimate_check`, передав путь
от корня проекта (`diagrams/<имя>.puml`). Исправляй ошибки и повторяй
проверку не более **3 раз**. Если после третьей попытки результат
`FAIL`, останови работу и верни ведущему агенту последний отчет
инструмента и описание проблемы.

| Сообщение инструмента | Причина | Исправление |
|---|---|---|
| `ERROR компиляция PlantUML, строка N` | неизвестный макрос, опечатка, неверные скобки | найди строку N (с учетом смещения), сверь название с таблицей раздела 3 или 4 |
| `ERROR компиляция ... No diagram found` | нет `@enduml` или `@startuml` | добавь недостающую строку |
| `id '...' не объявлен` | отношение ссылается на отсутствующий id (в том числе из-за опечатки в id) | объяви элемент либо исправь id в отношении |
| `повторное объявление '...'` | один id объявлен дважды | оставь одно объявление |
| `id '...' объявлен как X, по префиксу ожидается Y` | неверный тип элемента или неверный префикс | сверь с `01_Elements.md`; исправь макрос, если ошибся тип, или id, если ошибся префикс |
| `WARNING ... Rel_Flow ... без подписи` | поток без смысла | добавь подпись из `02_Relationships.md` |
| `WARNING Association(...)` | возможно, есть более точное отношение | замени на Realization, Serving, Influence и т. п. или оставь, если нужной пары нет |
| `WARNING элемент '...' не имеет ни одной связи` | висячий элемент | добавь связь из `02_Relationships.md` либо оставь и объясни в отчете |

Предупреждение об `Association` для пары Gap - Plateau и для связей
внутри Motivation ожидаемо и исправления не требует.

Не "исправляй" ошибку, подгоняя модель под инструмент: если id
объявлен как `Business_Process(app_cdp, ...)`, правильное решение -
сверить тип с `01_Elements.md`, а не переименовать id.

## 7. Частые ошибки моделей

- `Data_Object(...)`, `Process(...)`, `Component(...)`: правильные
  макросы - `Application_DataObject`, `Business_Process`,
  `Application_Component`.
- Система объявлена бизнес-процессом: `Business_Process(app_cdp, ...)`.
- Макросы `Lay_*` (не существуют в библиотеке ArchiMate).
- Отношение к необъявленному id.
- Перепутаны направления Realization и Serving:
  `Rel_Realization(as_profile_mgmt, app_cdp)` вместо
  `Rel_Realization(app_cdp, as_profile_mgmt)`.
- `Rel_Flow` без подписи; `Rel_Flow` между несвязанными элементами.
- Двойные кавычки внутри названия; перенос строки внутри скобок.
- Элементы, которых нет в `01_Elements.md`, добавлены для "полноты".
- В одной диаграмме смешаны As-is и To-be.

## 8. Пример

Прикладное представление RetailPro (To-be). Файл
`diagrams/retailpro_application_tobe.puml` проходит `archimate_check`
без ошибок и предупреждений.

```
@startuml
!include <archimate/Archimate>
title RetailPro: прикладная архитектура персонализации (To-be)

' --- Business ---
Business_Process(bp_segment, "Формировать сегменты клиентов")

' --- Application ---
Application_Component(app_crm, "CRM")
Application_Component(app_pos, "POS")
Application_Component(app_eshop, "Интернет-магазин")
Application_Component(app_cdp, "CDP")
Application_Component(app_analytics_platform, "Аналитическая платформа")
Application_Interface(ai_customer_api, "Customer API")
Application_Service(as_profile_mgmt, "Управление профилем клиента")
Application_Service(as_segmentation, "Сегментация клиентов")
Application_DataObject(data_customer_profile, "Профиль клиента")
Application_DataObject(data_segment, "Клиентский сегмент")

' --- Relationships ---
Rel_Flow_Down(app_crm, app_cdp, "данные клиента")
Rel_Flow_Down(app_pos, app_cdp, "покупки")
Rel_Flow_Down(app_eshop, app_cdp, "онлайн-заказы")
Rel_Flow(app_cdp, app_analytics_platform, "профиль и покупки")
Rel_Composition(app_cdp, ai_customer_api)
Rel_Realization(app_cdp, as_profile_mgmt)
Rel_Realization(app_analytics_platform, as_segmentation)
Rel_Access_rw(app_cdp, data_customer_profile)
Rel_Access_w(app_analytics_platform, data_segment)
Rel_Serving(as_segmentation, bp_segment)
@enduml
```

## 9. Формат `model/03_PlantUML.md`

Код диаграмм в этот файл не копируется, чтобы не было двух версий;
файл содержит отчет об этапе:

```
# Отчет этапа 3: PlantUML
Источник: model/01_Elements.md, model/02_Relationships.md
Агент: ea-modeler

| Диаграмма | Представление | Состояние | Элементов | Отношений | Попыток | Результат |
|---|---|---|---|---|---|---|
| diagrams/retailpro_application_tobe.puml | Прикладное | To-be | 10 | 10 | 2 | PASS |

## Исправления по результатам проверки
- попытка 1: id 'app_crm' не объявлен -> добавлено объявление
## Спорные решения
- ...
```

## 10. Контрольный список перед сдачей

1. Файл начинается с `@startuml` и `!include <archimate/Archimate>`,
   заканчивается `@enduml`.
2. Все макросы взяты из разделов 3 и 4.
3. Каждый id объявлен ровно один раз; префикс соответствует макросу.
4. Все id в отношениях объявлены; у каждого `Rel_Flow` есть подпись.
5. Нет `Grouping`, `Lay_*`, вложенных блоков и многострочных
   макросов.
6. Нет элементов и отношений, которых нет в `01_Elements.md` и
   `02_Relationships.md`.
7. Последний запуск `archimate_check` вернул `PASS`; предупреждения
   объяснены.
8. Спорные решения вынесены в отчет с пометкой "требует проверки
   архитектором".

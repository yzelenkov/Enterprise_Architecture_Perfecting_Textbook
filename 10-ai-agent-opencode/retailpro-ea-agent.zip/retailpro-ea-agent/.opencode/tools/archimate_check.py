#!/usr/bin/env python3
"""Проверка ArchiMate-модели на PlantUML: компиляция + анализ."""
import re
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
JAR = ROOT / "tools" / "plantuml.jar"

# Соглашение об идентификаторах (главы 4-9): префикс -> макрос
PREFIX = {
    "st": "Motivation_Stakeholder", "drv": "Motivation_Driver",
    "ass": "Motivation_Assessment", "goal": "Motivation_Goal",
    "out": "Motivation_Outcome", "req": "Motivation_Requirement",
    "pr": "Motivation_Principle", "con": "Motivation_Constraint",
    "cap": "Strategy_Capability", "res": "Strategy_Resource",
    "vs": "Strategy_ValueStream", "coa": "Strategy_CourseOfAction",
    "ba": "Business_Actor", "br": "Business_Role",
    "bp": "Business_Process", "fn": "Business_Function",
    "be": "Business_Event", "bs": "Business_Service",
    "bo": "Business_Object",
    "app": "Application_Component", "as": "Application_Service",
    "ai": "Application_Interface", "data": "Application_DataObject",
    "af": "Application_Function",
    "node": "Technology_Node", "dev": "Technology_Device",
    "sw": "Technology_SystemSoftware", "ts": "Technology_Service",
    "art": "Technology_Artifact",
    "net": "Technology_CommunicationNetwork",
    "wp": "Implementation_WorkPackage", "pl": "Implementation_Plateau",
    "gap": "Implementation_Gap", "del": "Implementation_Deliverable",
    "ie": "Implementation_Event",
}
LAYERS = (r"(?:Motivation|Strategy|Business|Application|Technology|"
          r"Physical|Implementation)")
ELEMENT = re.compile(r"^\s*(" + LAYERS + r"_\w+)\(\s*(\w+)\s*,")
RELATION = re.compile(
    r'^\s*(Rel_\w+)\(\s*(\w+)\s*,\s*(\w+)\s*(?:,\s*"([^"]*)")?\s*\)')


def compile_check(path, text):
    cmd = ["java", "-Djava.awt.headless=true", "-jar", str(JAR)]
    r = subprocess.run(cmd + ["-checkonly", str(path)],
                       capture_output=True, text=True)
    if r.returncode == 0:
        return []
    msg = (r.stdout + r.stderr).strip() or f"код {r.returncode}"
    s = subprocess.run(cmd + ["-syntax"], input=text,
                       capture_output=True, text=True)
    out = s.stdout.strip().splitlines()
    where = ""
    if len(out) > 1 and out[0] == "ERROR" and out[1].isdigit():
        start = next((i for i, l in enumerate(text.splitlines(), 1)
                      if "@startuml" in l), 1)
        where = f", строка {start + int(out[1])}"
    return [f"ERROR компиляция PlantUML{where}: {msg}"]


def lint(text):
    problems, declared, used = [], {}, []
    for no, line in enumerate(text.splitlines(), 1):
        m = ELEMENT.match(line)
        if m:
            macro, ident = m.groups()
            if ident in declared:
                problems.append(
                    f"ERROR строка {no}: повторное объявление '{ident}'")
            declared[ident] = macro
            expected = PREFIX.get(ident.split("_")[0])
            if expected and expected != macro:
                problems.append(
                    f"ERROR строка {no}: id '{ident}' объявлен как "
                    f"{macro}, по префиксу ожидается {expected}")
            continue
        m = RELATION.match(line)
        if m:
            used.append((no,) + m.groups())
    linked = set()
    for no, rel, src, dst, label in used:
        for ident in (src, dst):
            linked.add(ident)
            if ident not in declared:
                problems.append(
                    f"ERROR строка {no}: id '{ident}' не объявлен "
                    f"(PlantUML создаст его молча)")
        if rel.startswith("Rel_Flow") and not label:
            problems.append(
                f"WARNING строка {no}: {rel}({src}, {dst}) без подписи")
        motiv = all(declared.get(i, "").startswith("Motivation_")
                    for i in (src, dst))
        if rel.startswith("Rel_Association") and not motiv:
            problems.append(
                f"WARNING строка {no}: Association({src}, {dst}) - "
                f"есть ли более точное отношение?")
    for ident in declared:
        if ident not in linked:
            problems.append(
                f"WARNING элемент '{ident}' не имеет ни одной связи")
    return problems


def main():
    path = (ROOT / sys.argv[1]).resolve()
    if not path.is_file() or ROOT not in path.parents:
        print(f"ERROR файл не найден или вне проекта: {sys.argv[1]}")
        sys.exit(2)
    text = path.read_text(encoding="utf-8")
    problems = compile_check(path, text) + lint(text)
    errors = sum(p.startswith("ERROR") for p in problems)
    if problems:
        print("\n".join(problems))
    status = "FAIL" if errors else "PASS"
    print(f"РЕЗУЛЬТАТ: {status} (ошибок: {errors}, "
          f"предупреждений: {len(problems) - errors})")


if __name__ == "__main__":
    main()

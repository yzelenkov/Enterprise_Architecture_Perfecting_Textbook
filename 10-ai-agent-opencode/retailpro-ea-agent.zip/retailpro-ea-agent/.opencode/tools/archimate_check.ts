import { tool } from "@opencode-ai/plugin"
import path from "path"

export default tool({
  description: "Проверяет PlantUML-модель ArchiMate: компиляция и "
    + "анализ. Возвращает PASS или FAIL со списком замечаний.",
  args: {
    file: tool.schema.string().describe(
      "Путь к .puml-файлу от корня проекта, например "
      + "diagrams/retailpro.puml"),
  },
  async execute(args, context) {
    const script = path.join(context.directory,
      ".opencode/tools/archimate_check.py")
    const out = await Bun.$`python3 ${script} ${args.file}`
      .nothrow().text()
    return out.trim()
  },
})
